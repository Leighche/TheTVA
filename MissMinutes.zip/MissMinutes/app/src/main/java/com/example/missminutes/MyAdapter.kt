package com.example.missminutes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MyAdapter(private val taskList: ArrayList<Task>): RecyclerView.Adapter<MyAdapter.MyViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyAdapter.MyViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.list_item,
            parent, false)
        return MyViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: MyAdapter.MyViewHolder, position: Int) {

        val task : Task = taskList[position]
        holder.categoryName.text = task.categoryName
        holder.description.text = task.description
        holder.endDate.text = task.endDate
        holder.maxGoal.text = task.maxGoal
        holder.minGoal.text = task.minGoal
        holder.objective.text = task.objective
        holder.startDate.text = task.startDate
    }

    override fun getItemCount(): Int {
       return taskList.size
    }

    public class MyViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){

        val categoryName : TextView = itemView.findViewById(R.id.categoryName)
        val description : TextView = itemView.findViewById(R.id.description)
        val endDate : TextView = itemView.findViewById(R.id.endDate)
        val maxGoal : TextView = itemView.findViewById(R.id.maxGoal)
        val minGoal : TextView = itemView.findViewById(R.id.minGoal)
        val objective : TextView = itemView.findViewById(R.id.objective)
        val startDate : TextView = itemView.findViewById(R.id.startDate)



    }
}