package com.example.missminutes

data class Task(var categoryName: String ?= null, var description:String ?=null, var endDate: String ?= null, var maxGoal: String ?= null, var minGoal: String ?= null,var objective: String ?= null,var startDate: String ?= null, var taskImage :String ?= null, var hours: Long?= null)

