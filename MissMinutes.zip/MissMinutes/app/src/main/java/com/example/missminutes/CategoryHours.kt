package com.example.missminutes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.EventListener
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.QuerySnapshot

class CategoryHours : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var categoryArrayList : ArrayList<Task>
    private lateinit var myCategoryAdapter: MyCategoryAdapter
    private lateinit var db: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_category_hours)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)

        categoryArrayList = arrayListOf()

        myCategoryAdapter = MyCategoryAdapter(categoryArrayList)
        recyclerView.adapter = myCategoryAdapter

        EventChangeListener()

    }

    private fun EventChangeListener() {

        db = FirebaseFirestore.getInstance()
        val currentUser = FirebaseAuth.getInstance().currentUser
        val userUUID = currentUser?.uid/// Get the current user's ID

        db.collection("tasks").whereEqualTo("userId", userUUID)
            .addSnapshotListener {value, error ->
                if (error != null)
                {
                    Log.e("Firestore error", error.message.toString())
                    return@addSnapshotListener
                }

                val categoryHoursMap = HashMap<String, Long>()

                for (dc: DocumentChange in value?.documentChanges!!)
                {
                    if (dc.type == DocumentChange.Type.ADDED)
                    {
                        val task = dc.document.toObject(Task::class.java)
                        val categoryName = task.categoryName
                        val hours = task.hours?:0

                        val totalHours = categoryHoursMap.getOrDefault(categoryName,0)+hours

                    }
                }

                for ((categoryName, totalHours) in categoryHoursMap)
                {
                    Log.d("Category Hours", "Category: $categoryName, Total Hours: $totalHours")
                }

                myCategoryAdapter.notifyDataSetChanged()
            }

    }
}