package com.example.missminutes

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class Registration : AppCompatActivity() {

    private lateinit var Email: EditText
    private lateinit var Password: EditText
    private lateinit var ConfirmPassword: EditText
    private lateinit var btnSignUp: Button
    private lateinit var LoginPageLink: TextView
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        // View Binding
        Email = findViewById(R.id.RegUser)
        Password = findViewById(R.id.RegPass)
        ConfirmPassword = findViewById(R.id.RegConfirmPass)
        btnSignUp = findViewById(R.id.btnSignUp)
        LoginPageLink = findViewById(R.id.Redirect2Login)
        auth = Firebase.auth

        btnSignUp.setOnClickListener {
            signUp()
        }

        LoginPageLink.setOnClickListener {
            navigateToLogin()  // Ensure this only navigates to login when intended
        }
    }

    private fun signUp() {
        val email = Email.text.toString()
        val password = Password.text.toString()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Email and Password cannot be empty", Toast.LENGTH_SHORT).show()
            return
        }

        if (password != ConfirmPassword.text.toString()) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show()
            return
        }

        // Firebase Authentication for creating a new user
        auth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this) {
            if (it.isSuccessful) {
                Log.d("Registration", "Successfully registered, navigating to RegUploadPic")
                navigateToRegUpload()
            } else {
                Toast.makeText(this, "Registration failed: ${it.exception?.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun navigateToRegUpload() {
        Log.d("Registration", "Navigating to RegUploadPic")
        val intent = Intent(this, RegUploadPic::class.java)
        startActivity(intent)
        finish()  // Ensure the current activity is closed after navigation
    }

    private fun navigateToLogin() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()  // Ensure the current activity is closed after navigation
    }
}
