package com.example.missminutes

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class favouriteTimesheet : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favourite_timesheet)
    }
}